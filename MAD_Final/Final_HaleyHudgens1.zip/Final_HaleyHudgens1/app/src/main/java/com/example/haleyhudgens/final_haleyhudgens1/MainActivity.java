package com.example.haleyhudgens.final_haleyhudgens1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    private BurritoInfo myBuiltBurrito = new BurritoInfo();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button bPlace = (Button) findViewById(R.id.button2);
        View.OnClickListener onclick = new View.OnClickListener() {
            public void onClick(View view) {
                findBurritoPlace(view);
            }
        };
        bPlace.setOnClickListener(onclick);
    }

    public void buildBurrito(View view) {
        TextView burritoText = (TextView)findViewById(R.id.message);
        //edit text
        EditText name = (EditText)findViewById(R.id.editText);
        String nameValue = name.getText().toString();
        //toggle button
        ToggleButton toggle = (ToggleButton) findViewById(R.id.toggleButton);
        boolean filling = toggle.isChecked();
        String fill = String.valueOf(filling);
        //spinner
        Spinner place = (Spinner) findViewById(R.id.spinner);
        String location = String.valueOf(place.getSelectedItem());
        Integer loc_int = place.getSelectedItemPosition();

        burritoText.setText("The " + nameValue + "is a burrito, with " + fill + "you'd like to eat on" +location);
        ImageView burrito = (ImageView) findViewById(R.id.imageView);
        burrito.setImageResource(R.drawable.burrito);

    }

    public void findBurritoPlace(View view) {


        Spinner place1 = (Spinner) findViewById(R.id.spinner);
        Integer loc_int = place1.getSelectedItemPosition();
        myBuiltBurrito.setBurritoPlace(loc_int);
        String suggestedBurritoPlace = myBuiltBurrito.getBurrito();
        String suggestedBurritoURL = myBuiltBurrito.getBurritoURL();

        //create an Intent
        Intent intent = new Intent(this, BurritoPlace.class);

        //passdata
        intent.putExtra("burritoPlaceName", suggestedBurritoPlace);
        intent.putExtra("burritoPlaceURL", suggestedBurritoURL);


        //start intent
        startActivity(intent);

    }
}
