package com.example.haleyhudgens.final_haleyhudgens1;

/**
 * Created by haleyhudgens on 12/17/17.
 */

public class BurritoInfo {
    private String burritoP;
    private String burritoURL;

    private void setBurritoInfo(Integer burritoPlace){
        switch (burritoPlace){
            case 0: //the hill
                burritoP = "Illegal Petes";
                burritoURL = "illegalpetes.com/";
                break;
            case 1: //29th street
                burritoP = "Chipolte";
                burritoURL = "https://www.chipotle.com/";
                break;
            case 2: //pearl
                burritoP = "BarTaco";
                burritoURL = "https://bartaco.com/location/boulder/";
                break;
            default:
        }
    }

    public void setBurritoPlace(Integer burritoPlace){

        setBurritoInfo(burritoPlace);
    }

    public String getBurrito(){

        return burritoP;
    }

    public void setBurritoURL(Integer burritoPlace){

        setBurritoInfo(burritoPlace);
    }

    public String getBurritoURL(){

        return burritoURL;
    }
}
