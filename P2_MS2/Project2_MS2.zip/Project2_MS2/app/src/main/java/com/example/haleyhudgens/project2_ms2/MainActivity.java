package com.example.haleyhudgens.project2_ms2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import 	android.widget.FrameLayout;


public class MainActivity extends AppCompatActivity {

    private PlanetInfo sunObj = new PlanetInfo();
    private PlanetInfo mercuryObj = new PlanetInfo();
    private PlanetInfo venusObj = new PlanetInfo();
    private PlanetInfo earthObj = new PlanetInfo();
    private PlanetInfo marsObj = new PlanetInfo();
    private PlanetInfo jupiterObj = new PlanetInfo();
    private PlanetInfo saturnObj = new PlanetInfo();
    private PlanetInfo uranusObj = new PlanetInfo();
    private PlanetInfo neptuneObj = new PlanetInfo();
    private PlanetInfo plutoObj = new PlanetInfo();


    public String pName;
    public String pURL;
    public String pFact;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //get button
        final ImageButton sun = (ImageButton) findViewById(R.id.sunButton);
        final ImageButton mercury = (ImageButton) findViewById(R.id.mercuryButton);
        final ImageButton venus = (ImageButton) findViewById(R.id.venusButton);
        final ImageButton earth = (ImageButton) findViewById(R.id.earthButton);
        final ImageButton mars = (ImageButton) findViewById(R.id.marsButton);
        final ImageButton jupiter = (ImageButton) findViewById(R.id.jupiterButton);
        final ImageButton saturn = (ImageButton) findViewById(R.id.saturnButton);
        final ImageButton uranus = (ImageButton) findViewById(R.id.uranusButton);
        final ImageButton neptune = (ImageButton) findViewById(R.id.neptuneButton);
        final ImageButton pluto = (ImageButton) findViewById(R.id.plutoButton);

        //create listener
        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
            selectPlanet(view);
        }
        };


        //add listener to the button
        sun.setOnClickListener(onclick);
        mercury.setOnClickListener(onclick);
        venus.setOnClickListener(onclick);
        earth.setOnClickListener(onclick);
        mars.setOnClickListener(onclick);
        jupiter.setOnClickListener(onclick);
        saturn.setOnClickListener(onclick);
        uranus.setOnClickListener(onclick);
        neptune.setOnClickListener(onclick);
        pluto.setOnClickListener(onclick);

    }

    public void selectPlanet(View view) {

        switch (view.getId()) {

            case R.id.sunButton:
                //set planet
                sunObj.setPlanetName(R.id.sunButton);
                //get planet name
                pName = sunObj.getPlanetName();
                //get planet url
                pURL = sunObj.getPlanetURL();
                //get planet fact
                pFact = sunObj.getPlanetFact();

                Log.i("name", pName);
                Log.i("url", pURL);
                Log.i("fact", pFact);
                //create an Intent
                Intent intent1 = new Intent(this, PlanetActivity.class);

                //pass data
                intent1.putExtra("pName", pName);
                intent1.putExtra("pURL", pURL);
                intent1.putExtra("pFact", pFact);

                //start intent
                startActivity(intent1);

                break;

            case R.id.mercuryButton:
                //set planet
                mercuryObj.setPlanetName(R.id.sunButton);
                //get planet name
                pName = mercuryObj.getPlanetName();
                //get planet url
                pURL = mercuryObj.getPlanetURL();

                Log.i("name", pName);
                Log.i("url", pURL);
                //create an Intent
                Intent intent2 = new Intent(this, PlanetActivity.class);

                //pass data
                intent2.putExtra("pName", pName);
                intent2.putExtra("pURL", pURL);

                //start intent
                startActivity(intent2);


                break;
            case R.id.venusButton:
                //set planet
                venusObj.setPlanetName(R.id.sunButton);
                //get planet name
                pName = venusObj.getPlanetName();
                //get planet url
                pURL = venusObj.getPlanetURL();

                Log.i("name", pName);
                Log.i("url", pURL);
                //create an Intent
                Intent intent3 = new Intent(this, PlanetActivity.class);

                //pass data
                intent3.putExtra("pName", pName);
                intent3.putExtra("pURL", pURL);

                //start intent
                startActivity(intent3);

                break;
            case R.id.earthButton:
                //set planet
                earthObj.setPlanetName(R.id.sunButton);
                //get planet name
                pName = earthObj.getPlanetName();
                //get planet url
                pURL = earthObj.getPlanetURL();

                Log.i("name", pName);
                Log.i("url", pURL);
                //create an Intent
                Intent intent4 = new Intent(this, PlanetActivity.class);

                //pass data
                intent4.putExtra("pName", pName);
                intent4.putExtra("pURL", pURL);

                //start intent
                startActivity(intent4);

                break;
            case R.id.marsButton:
                //set planet
                marsObj.setPlanetName(R.id.sunButton);
                //get planet name
                pName = marsObj.getPlanetName();
                //get planet url
                pURL = marsObj.getPlanetURL();

                Log.i("name", pName);
                Log.i("url", pURL);
                //create an Intent
                Intent intent5 = new Intent(this, PlanetActivity.class);

                //pass data
                intent5.putExtra("pName", pName);
                intent5.putExtra("pURL", pURL);

                //start intent
                startActivity(intent5);
                break;
            case R.id.jupiterButton:
                //set planet
                jupiterObj.setPlanetName(R.id.sunButton);
                //get planet name
                pName = jupiterObj.getPlanetName();
                //get planet url
                pURL = jupiterObj.getPlanetURL();

                Log.i("name", pName);
                Log.i("url", pURL);
                //create an Intent
                Intent intent6 = new Intent(this, PlanetActivity.class);

                //pass data
                intent6.putExtra("pName", pName);
                intent6.putExtra("pURL", pURL);

                //start intent
                startActivity(intent6);
                break;
            case R.id.saturnButton:
                //set planet
                saturnObj.setPlanetName(R.id.sunButton);
                //get planet name
                pName = saturnObj.getPlanetName();
                //get planet url
                pURL = saturnObj.getPlanetURL();

                Log.i("name", pName);
                Log.i("url", pURL);
                //create an Intent
                Intent intent7 = new Intent(this, PlanetActivity.class);

                //pass data
                intent7.putExtra("pName", pName);
                intent7.putExtra("pURL", pURL);

                //start intent
                startActivity(intent7);

                break;
            case R.id.uranusButton:
                //set planet
                uranusObj.setPlanetName(R.id.sunButton);
                //get planet name
                pName = uranusObj.getPlanetName();
                //get planet url
                pURL = uranus.getPlanetURL();

                Log.i("name", pName);
                Log.i("url", pURL);
                //create an Intent
                Intent intent8 = new Intent(this, PlanetActivity.class);

                //pass data
                intent8.putExtra("pName", pName);
                intent8.putExtra("pURL", pURL);

                //start intent
                startActivity(intent8);

                break;
            case R.id.neptuneButton:
                //set planet
                neptuneObj.setPlanetName(R.id.sunButton);
                //get planet name
                pName = neptuneObj.getPlanetName();
                //get planet url
                pURL = neptuneObj.getPlanetURL();

                Log.i("name", pName);
                Log.i("url", pURL);
                //create an Intent
                Intent intent9 = new Intent(this, PlanetActivity.class);

                //pass data
                intent9.putExtra("pName", pName);
                intent9.putExtra("pURL", pURL);

                //start intent
                startActivity(intent9);

                break;
            case R.id.plutoButton:
                //set planet
                plutoObj.setPlanetName(R.id.sunButton);
                //get planet name
                pName = plutoObj.getPlanetName();
                //get planet url
                pURL = plutoObj.getPlanetURL();

                Log.i("name", pName);
                Log.i("url", pURL);
                //create an Intent
                Intent intent10 = new Intent(this, PlanetActivity.class);

                //pass data
                intent10.putExtra("pName", pName);
                intent10.putExtra("pURL", pURL);

                //start intent
                startActivity(intent10);

                break;

            default:
                //set planet
                plutoObj.setPlanetName(R.id.sunButton);
                //get planet name
                pName = plutoObj.getPlanetName();
                //get planet url
                pURL = plutoObj.getPlanetURL();

                Log.i("name", pName);
                Log.i("url", pURL);
                //create an Intent
                Intent intent11 = new Intent(this, PlanetActivity.class);

                //pass data
                intent11.putExtra("pName", pName);
                intent11.putExtra("pURL", pURL);

                //start intent
                startActivity(intent11);
                break;
        }

    }


}
