package com.example.haleyhudgens.project2_ms2;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class PlanetActivity extends AppCompatActivity {
    private String planetName;
    private String planetURL;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_planet);
        //get intent
        Intent intent = getIntent();
        planetName = intent.getStringExtra("pName");
        planetURL = intent.getStringExtra("pURL");
        Log.i("name received", planetName);
        Log.i("url received", planetURL);

        TextView planetTitle = (TextView) findViewById(R.id.planetTextView);
        planetTitle.setText(planetName);
        TextView factGenerator = (TextView) findViewById(R.id.funFact);
        factGenerator.setText(planetName);

        final ImageButton imageButton = (ImageButton) findViewById(R.id.imageButton);
        //create listener
        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                loadWebSite(view);
            }
        };

    }

    public void loadWebSite(View view){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(planetURL));
        startActivity(intent);
    }
}
