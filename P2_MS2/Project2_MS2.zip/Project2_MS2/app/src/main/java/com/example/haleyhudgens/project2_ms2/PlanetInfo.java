package com.example.haleyhudgens.project2_ms2;

/**
 * Created by haleyhudgens on 11/29/17.
 */

public class PlanetInfo {
    private String planetName;
    private String planetURL;
    private String planetFacts[];
    private String planetImage;


    public void setPlanetInfo(Integer planetInfo){
        switch (planetInfo){
            case 0:
                planetName="Sun";
                planetURL="https://www.nasa.gov/sun";
                planetFacts = new String[]{"The Sun is all the colours mixed together, this appears white to our eyes.",
                        "One million Earths could fit inside the Sun.",
                        "The Sun contains 99.86% of the mass in the Solar System",
                        "Eventually, the Sun will expand to consume the Earth.",
                        "The atmosphere of the Sun is composed of three layers: the photosphere, the chromosphere, and the corona"};
                break;
            case 1:
                planetName="Mercury";
                planetURL="https://www.nasa.gov/planetmercury";
                planetFacts = new String[] {"A day on the surface of Mercury lasts 176 Earth days.",
                        "Mercury is the smallest planet in the Solar System.",
                        "Mercury is the most cratered planet in the Solar System.",
                        "Only two spacecraft have ever visited Mercury.",
                        "Mercury is named for the Roman messenger to the gods."};
                break;
            case 2:
                planetName="Venus";
                planetURL="https://www.nasa.gov/venus";
                planetFacts = new String[] {"Venus is thought to be made up of a central iron core, rocky mantle and silicate crust.",
                        "Venus rotates in the opposite direction to most other planets.",
                        "Venus is the second brightest object in the night sky to the moon.",
                        "Venus is also known as the Morning Star and the Evening Star.",
                        "The Russians sent the first mission to Venus."};
                break;
            case 3:
                planetName="Earth";
                planetURL="https://www.nasa.gov/topics/earth/index.html";
                planetFacts = new String[] {"The Earth’s rotation is gradually slowing.",
                        "Earth is the only planet not named after a god.",
                        "The Earth is the densest planet in the Solar System.",
                        "The Earth was once believed to be the centre of the universe.",
                        "Earth is a squashed sphere"};
                break;
            case 4:
                planetName="mars";
                planetURL="https://www.nasa.gov/mission_pages/mars/main/index.html";
                planetFacts = new String[] {"Mars and Earth have approximately the same landmass.",
                        "Only 18 missions to Mars have been successful.",
                        "Mars has the largest dust storms in the solar system.",
                        "On Mars the Sun appears about half the size as it does on Earth.",
                        "Pieces of Mars have fallen to Earth."};
                break;
            case 5:
                planetName="Jupiter";
                planetURL="https://www.nasa.gov/jupiter";
                planetFacts = new String[] {"The ancient Babylonians were the first to record their sightings of Jupiter.",
                        "The Great Red Spot is a huge storm on Jupiter.",
                        "Jupiter’s moon Ganymede is the largest moon in the solar system",
                        "Eight spacecraft have visited Jupiter.", "Jupiter has the shortest day of all the planets lasting 9 hours and 5 mintues."};
                break;
            case 6:
                planetName="Saturn";
                planetURL="https://www.nasa.gov/saturn";
                planetFacts = new String[] {"Saturn can be seen with the naked eye. It can also easily be seen through binoculars or a small telescope",
                        "Saturn is the flattest planet.",
                        "Saturn has 150 moons and smaller moonlets.",
                        "Four spacecraft have visited Saturn.",
                        "Saturn orbits the Sun once every 29.4 Earth years."};
                break;
            case 7:
                planetName="Uranus";
                planetURL="https://www.nasa.gov/uranus";
                planetFacts = new String[] {"Uranus is often referred to as an “ice giant” planet.",
                        "Uranus makes one trip around the Sun every 84 Earth years.",
                        "Uranus has two sets of very thin dark coloured rings.",
                        "Uranus’ moons are named after characters created by William Shakespeare and Alexander Pope.",
                        "Uranus was officially discovered by Sir William Herschel in 1781."};
                break;
            case 8:
                planetName="Neptune";
                planetURL="https://www.nasa.gov/subject/3157/neptune/";
                planetFacts = new String[] {"Neptune was not known to the ancients. It was first observed in 1846",
                        "Neptune spins on its axis very rapidly.\n" +
                                "Its equatorial clouds take 18 hours to make one rotation. This is because Neptune is not solid body.",
                        "Neptune has 14 moons.",
                        "The atmosphere of Neptune is made of hydrogen and helium, with some methane."};
                break;
            case 9:
                planetName="Pluto";
                planetURL="https://solarsystem.nasa.gov/planets/pluto";
                planetFacts = new String[] {"Pluto is named after the Greek god of the underworld.",
                        "Pluto was discovered on February 18th, 1930 by the Lowell Observatory.",
                        "Pluto sometimes has an atmosphere. When Pluto elliptical orbit takes it closer to the Sun, its surface ice thaws and forms a thin atmosphere primarily of nitrogen which slowly escapes the planet",
                        "Pluto has been visited by one spacecraft.The New Horizons spacecraft, which was launched in 2006, flew by Pluto on the 14th of July 2015 and took a series of images and other measurements.",
                        "Pluto hasn't completed an orbit since it's discovery. It was dicovered 87 years ago and it takes 247.68 Earth years to cmpletes its orbit. "};

                break;
            default:
                planetName="none";
                planetURL="https://www.nasa.gov/";
                planetFacts = new String[] {"Pluto is named after the Greek god of the underworld.",
                        "Pluto was discovered on February 18th, 1930 by the Lowell Observatory.",
                        "Pluto sometimes has an atmosphere. When Pluto elliptical orbit takes it closer to the Sun, its surface ice thaws and forms a thin atmosphere primarily of nitrogen which slowly escapes the planet",
                        "Pluto has been visited by one spacecraft.The New Horizons spacecraft, which was launched in 2006, flew by Pluto on the 14th of July 2015 and took a series of images and other measurements.",
                        "Pluto hasn't completed an orbit since it's discovery. It was dicovered 87 years ago and it takes 247.68 Earth years to cmpletes its orbit. "};

        }

    }


    public void setPlanetName(Integer planetInfo){

        setPlanetInfo(planetInfo);
    }

    public void setPlanetURL(Integer planetInfo){

        setPlanetInfo(planetInfo);
    }
    public void setPlanetFact(Integer planetInfo){

        setPlanetInfo(planetInfo);
    }

    public String getPlanetName(){

        return planetName;
    }

    public String getPlanetURL(){

        return planetURL;
    }
    public String getPlanetFact(){

        return planetFacts[];
    }
}
