package com.example.haleyhudgens.lab5;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ToggleButton;
import android.widget.Spinner;
import android.widget.Toast;
import android.content.Context;
import android.widget.RadioGroup;
import android.graphics.Canvas;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void colorize(View view) {

        //edit text
        EditText name = (EditText) findViewById(R.id.editText);
        String nameValue = name.getText().toString();

        //toggle button
        ToggleButton toggle = (ToggleButton) findViewById(R.id.toggleButton);
        boolean glass = toggle.isChecked();

        //spinner
        Spinner place = (Spinner) findViewById(R.id.spinner);
        String placeType = String.valueOf(place.getSelectedItem());

        //radio buttons
        RadioGroup time = (RadioGroup) findViewById(R.id.radioGroup);
        int dayTime = time.getCheckedRadioButtonId();

        //image view
        ImageView colorpic = (ImageView) findViewById(R.id.imageView);

        String yourColor = null;

        if (dayTime == -1) {
            //toast
            Context context = getApplicationContext();
            CharSequence text = "Please select a time of day";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        } else {
            if (glass) { //full
                if (dayTime == R.id.radioButton1) { //morning-pale
                    switch (placeType) {
                        case "the ocean":
                            yourColor = "pale light blue";
                            colorpic.setImageResource(R.drawable.palelightblue);
                            break;
                        case "the forest":
                            yourColor = "pale light green";
                            colorpic.setImageResource(R.drawable.palelightgreen);
                            break;
                        case "the desert":
                            yourColor = "pale light red";
                            colorpic.setImageResource(R.drawable.palelightred);
                            break;
                        case "outer space":
                            yourColor = " pale light purple";
                            colorpic.setImageResource(R.drawable.palelightpurple);
                            break;
                        default:
                            yourColor = "light blue";
                    }
                } else if (dayTime == R.id.radioButton2) {
                    switch (placeType) {
                        case "the ocean":
                            yourColor = "light blue";
                            colorpic.setImageResource(R.drawable.lightblue);
                            break;
                        case "the forest":
                            yourColor = "light green";
                            colorpic.setImageResource(R.drawable.lightgreen);
                            break;
                        case "the desert":
                            yourColor = "light red";
                            colorpic.setImageResource(R.drawable.lightred);
                            break;
                        case "outer space":
                            yourColor = "light purple";
                            colorpic.setImageResource(R.drawable.lightpurple);
                            break;
                        default:
                            yourColor = "light blue";
                    }
                } else if (dayTime == R.id.radioButton3) {
                    switch (placeType) {
                        case "the ocean":
                            yourColor = "bright light blue";
                            colorpic.setImageResource(R.drawable.lightbrightblue);
                            break;
                        case "the forest":
                            yourColor = "bright light green";
                            colorpic.setImageResource(R.drawable.brightlightgreen);
                            break;
                        case "the desert":
                            yourColor = "bright light red";
                            colorpic.setImageResource(R.drawable.brightlightred);
                            break;
                        case "outer space":
                            yourColor = "bright light purple";
                            colorpic.setImageResource(R.drawable.brightlightpurple);
                            break;
                        default:
                            yourColor = "light blue";
                    }
                }
            } else { //empty
                if (dayTime == R.id.radioButton1) { //morning-pale
                    switch (placeType) {
                        case "the ocean":
                            yourColor = "pale dark blue";
                            colorpic.setImageResource(R.drawable.paledarkblue);
                            break;
                        case "the forest":
                            yourColor = "pale dark green";
                            colorpic.setImageResource(R.drawable.paledarkgreen);
                            break;
                        case "the desert":
                            yourColor = "pale dark red";
                            colorpic.setImageResource(R.drawable.paledarkred);
                            break;
                        case "outer space":
                            yourColor = " pale dark purple";
                            colorpic.setImageResource(R.drawable.paledarkpurple);
                            break;
                        default:
                            yourColor = "dark blue";
                    }
                } else if (dayTime == R.id.radioButton2) {
                    switch (placeType) {
                        case "the ocean":
                            yourColor = "bright dark blue";
                            colorpic.setImageResource(R.drawable.brightdarkblue);
                            break;
                        case "the forest":
                            yourColor = "bright dark green";
                            colorpic.setImageResource(R.drawable.brightdarkgreen);
                            break;
                        case "the desert":
                            yourColor = "bright dark red";
                            colorpic.setImageResource(R.drawable.brightdarkred);
                            break;
                        case "outer space":
                            yourColor = "bright dark purple";
                            colorpic.setImageResource(R.drawable.brightdarkpurple);
                            break;
                        default:
                            yourColor = "dark blue";
                    }
                } else if (dayTime == R.id.radioButton3) {
                    switch (placeType) {
                        case "the ocean":
                            yourColor = "dark blue";
                            colorpic.setImageResource(R.drawable.darkblue);
                            break;
                        case "the forest":
                            yourColor = "dark green";
                            colorpic.setImageResource(R.drawable.darkgreen);
                            break;
                        case "the desert":
                            yourColor = "dark red";
                            colorpic.setImageResource(R.drawable.darkred);
                            break;
                        case "outer space":
                            yourColor = "dark purple";
                            colorpic.setImageResource(R.drawable.darkpurple);
                            break;
                        default:
                            yourColor = "dark blue";
                    }
                }
            }
        }

            TextView colorText = (TextView) findViewById(R.id.colorizeTextView);
            colorText.setText(nameValue + ", your color is " + yourColor);

        }
    }





